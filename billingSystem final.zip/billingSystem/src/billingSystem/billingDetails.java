package billingSystem;

import java.awt.Color;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.SystemColor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.DecimalFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JSeparator;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JScrollPane;

import net.proteanit.sql.DbUtils;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;
import javax.swing.JButton;

public class billingDetails {

	private JFrame frame;
	private JTextField txtFieldNumber;
	private JComboBox comboBox;
	private JTextField textFieldPrice;
	private JTextField textFieldQuantity;
	private JTable table;
	private JTextField textFieldTotalAmt;
	private JTextField textFieldRefNo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					billingDetails window = new billingDetails();
					window.frame.setVisible(true);			
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		);
	}

	/**
	 * Create the application.
	 */
	public billingDetails() {
		initialize();
	}
	// Snippet to fill combobox with items in table itemDetails
	public void fillComboBox()
	{
		try{
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
			Statement mystmt=(Statement) conn.createStatement();
			//System.out.println("connected");
			String query="select * From itemdetails";
			PreparedStatement pst =(PreparedStatement) conn.prepareStatement(query);
			ResultSet rs = pst.executeQuery();
			while(rs.next())
			{
				comboBox.addItem(rs.getString("ItemName"));
			}            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}	

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setForeground(Color.DARK_GRAY);
		frame.setBounds(100, 100, 906, 702);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel MobileNumber = new JLabel("Mobile No");
		MobileNumber.setForeground(Color.BLACK);
		MobileNumber.setFont(new Font("Segoe Print", Font.BOLD, 20));
		MobileNumber.setBounds(528, 68, 113, 24);
		frame.getContentPane().add(MobileNumber);
		
		txtFieldNumber = new JTextField();
		txtFieldNumber.setFont(new Font("Tahoma", Font.BOLD, 24));
		txtFieldNumber.setForeground(SystemColor.textHighlight);
		txtFieldNumber.setBackground(Color.LIGHT_GRAY);
		txtFieldNumber.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
		
				// Snippet to verify the mobile number pattern
				
				String phoneNumber1= txtFieldNumber.getText();
				Pattern pattern = Pattern.compile("\\d{10}");
			    Matcher matcher = pattern.matcher(phoneNumber1);

			      if (matcher.matches()) {
			    	 // System.out.println("Phone Number Valid");
			    	  
			   // Snippet to Generate reference number like unique id 	  
			    	  
			    	  try{
				    	  int a;
				    	  String b;
						    Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
						    String query = "SELECT COUNT(itemUnitPrice) FROM usercartdetails";
						    PreparedStatement pst=(PreparedStatement) conn.prepareStatement(query);
						    ResultSet rs = pst.executeQuery();
						    rs.next();
					//	  System.out.println(rs.getString("count(itemUnitPrice)"));
						   if(rs.getString("count(itemUnitPrice)").equals("0")){
						    	System.out.println("iF");
						    	textFieldRefNo.setText("1");
						    }
						    else{
						    String query1 = "SELECT MAX(uniqueId) FROM usercartdetails";
						    System.out.println("else");
						    PreparedStatement pst1=(PreparedStatement) conn.prepareStatement(query1);	
						    
						    ResultSet rs1 = pst1.executeQuery();
						    rs1.next();
						    a = rs1.getInt("MAX(uniqueId)");
						    pst1.close();
						    System.out.println(a++);
						    b=Integer.toString(a++);
						    textFieldRefNo.setText(b);
						    }
						   
						    pst.close();
						    }
						    catch (Exception e) {
					  			e.printStackTrace();
					  		}
				      
			    	 
			      }
			      else
			      {
			    	  JOptionPane.showMessageDialog(null, "Phone Number must be in the form 0000000000");
			    }
			     ////////////////// CHeck for refno code snippet
			      
			/*      try{
			    	  int a;
			    	  String b;
					    Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","root");
					    String query = "SELECT COUNT(itemUnitPrice) FROM usercartdetails";
					    PreparedStatement pst=(PreparedStatement) conn.prepareStatement(query);
					    ResultSet rs = pst.executeQuery();
					    rs.next();
				//	  System.out.println(rs.getString("count(itemUnitPrice)"));
					   if(rs.getString("count(itemUnitPrice)").equals("0")){
					    	System.out.println("iF");
					    	textFieldRefNo.setText("1");
					    }
					    else{
					    String query1 = "SELECT MAX(uniqueId) FROM usercartdetails";
					    System.out.println("else");
					    PreparedStatement pst1=(PreparedStatement) conn.prepareStatement(query1);	
					    
					    ResultSet rs1 = pst1.executeQuery();
					    rs1.next();
					    a = rs1.getInt("MAX(uniqueId)");
					    pst1.close();
					    System.out.println(a++);
					    b=Integer.toString(a++);
					    textFieldRefNo.setText(b);
					    }
					   
					    pst.close();
					    }
					    catch (Exception e) {
				  			e.printStackTrace();
				  		}
			      
			      */
			      
			      
			      
			}
		});
		txtFieldNumber.setBounds(643, 59, 200, 48);
		frame.getContentPane().add(txtFieldNumber);
		txtFieldNumber.setColumns(10);
		
		comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				// Snippet to display item price per unit in textfield from itemDetails table based on comboBox selection
				
				try {
					Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
				String query= "select * From itemdetails where ItemName= ?";
				PreparedStatement pst =(PreparedStatement) conn.prepareStatement(query);
				pst.setString(1, (String) comboBox.getSelectedItem());
				ResultSet rs = pst.executeQuery();
			//	System.out.println("reached1");
				while(rs.next())
				{
			//		System.out.println("reached2");
					textFieldPrice.setText(rs.getString("itemPricePerUnit"));
				}
				pst.close();
				} catch (Exception e1) {
					e1.printStackTrace();
				
			}
		}
			});
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
		comboBox.setBackground(Color.LIGHT_GRAY);
		comboBox.setBounds(10, 122, 145, 39);
		frame.getContentPane().add(comboBox);
						
JLabel lblBillingSystem = new JLabel("Billing System");
lblBillingSystem.setFont(new Font("Tempus Sans ITC", Font.BOLD, 30));
lblBillingSystem.setBounds(10, 11, 224, 39);
frame.getContentPane().add(lblBillingSystem);
JSeparator separator = new JSeparator();
separator.setBounds(10, 48, 833, 2);
frame.getContentPane().add(separator);
JLabel lblItem = new JLabel("Item");
lblItem.setForeground(SystemColor.textHighlight);
lblItem.setFont(new Font("Segoe Print", Font.BOLD, 20));
lblItem.setBounds(10, 86, 46, 25);
frame.getContentPane().add(lblItem);
JLabel lblPrice = new JLabel("Price");
lblPrice.setForeground(SystemColor.textHighlight);
lblPrice.setFont(new Font("Segoe Print", Font.BOLD, 20));
lblPrice.setBounds(170, 86, 53, 24);
frame.getContentPane().add(lblPrice);
textFieldPrice = new JTextField();
textFieldPrice.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
	
	}
});
textFieldPrice.setFont(new Font("Tahoma", Font.BOLD, 22));
textFieldPrice.setBackground(Color.LIGHT_GRAY);
textFieldPrice.setForeground(Color.DARK_GRAY);
textFieldPrice.setBounds(165, 122, 103, 39);
frame.getContentPane().add(textFieldPrice);
textFieldPrice.setColumns(10);
JLabel lblQuantity = new JLabel("Quantity");
lblQuantity.setForeground(SystemColor.textHighlight);
lblQuantity.setFont(new Font("Segoe Print", Font.BOLD, 20));
lblQuantity.setBounds(278, 86, 95, 24);
frame.getContentPane().add(lblQuantity);
textFieldQuantity = new JTextField();
textFieldQuantity.addKeyListener(new KeyAdapter() {
	@Override
	public void keyTyped(KeyEvent arg0) {
		char c = arg0.getKeyChar();
		if(!(Character.isDigit(c) || (c == KeyEvent.VK_BACK_SPACE)||c == KeyEvent.VK_DELETE)){
			JOptionPane.showMessageDialog(null, "Please enter Number for quantity");
			arg0.consume();
		} 
	}
});
textFieldQuantity.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		
		// Snippet to get the user entered quantity in textfield
		
		String quantity= textFieldQuantity.getText();
		
		System.out.println(quantity);
		
	}
});
textFieldQuantity.setFont(new Font("Tahoma", Font.BOLD, 22));
textFieldQuantity.setBackground(Color.LIGHT_GRAY);
textFieldQuantity.setForeground(Color.DARK_GRAY);
textFieldQuantity.setColumns(10);
textFieldQuantity.setBounds(278, 122, 80, 39);
frame.getContentPane().add(textFieldQuantity);
JScrollPane yourCart = new JScrollPane();
yourCart.setBounds(10, 222, 651, 296);
frame.getContentPane().add(yourCart);
JScrollPane scrollPaneYourCart = new JScrollPane();
yourCart.setViewportView(scrollPaneYourCart);
table = new JTable();
scrollPaneYourCart.setViewportView(table);
table.setForeground(Color.BLACK);
JLabel lblPurchaseListInformation = new JLabel("Your Cart :");
lblPurchaseListInformation.setForeground(SystemColor.textHighlight);
lblPurchaseListInformation.setFont(new Font("Segoe Print", Font.BOLD, 20));
lblPurchaseListInformation.setBounds(10, 184, 124, 35);
frame.getContentPane().add(lblPurchaseListInformation);
JLabel lblTotalAmount = new JLabel("Total Amount :");
lblTotalAmount.setForeground(SystemColor.textHighlight);
lblTotalAmount.setFont(new Font("Tempus Sans ITC", Font.BOLD, 25));
lblTotalAmount.setBounds(267, 609, 189, 43);
frame.getContentPane().add(lblTotalAmount);
textFieldTotalAmt = new JTextField();
textFieldTotalAmt.setFont(new Font("Tahoma", Font.BOLD, 26));
textFieldTotalAmt.setBackground(Color.LIGHT_GRAY);
textFieldTotalAmt.setBounds(466, 597, 212, 55);
frame.getContentPane().add(textFieldTotalAmt);
textFieldTotalAmt.setColumns(10);
JButton btnSubmit = new JButton("Check Out");
btnSubmit.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent arg0) {
		
		//code to add subtotal in usercartdetails table and display in total amount column
		
		try {
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
		String query= "select SUM(subTotal) From usercartdetails WHERE uniqueId = ? ";
		PreparedStatement pst =(PreparedStatement) conn.prepareStatement(query);
		pst.setString(1, (String) textFieldRefNo.getText());
		
		ResultSet rs = pst.executeQuery();
		rs.next();
	/*	
		DecimalFormat df = new DecimalFormat("#.00");
		System.out.println(df.format(rs.getString("SUM(subTotal)")));
	*/	
		
	//	System.out.println("reached1");
			//		System.out.println("reached2");
		
		String a = rs.getString("SUM(subTotal)");
		float b = Float.parseFloat(a);
		DecimalFormat df = new DecimalFormat("#.00");
		String c = df.format(b);
	//	double b = Math.round(d*100.0)/100;
	//	String c = String.valueOf(b);
	//	String.format("%.2f", c);
		System.out.println(b);
			
		
		textFieldTotalAmt.setText(c);
		
		
		pst.close();
		} catch (Exception e1) {
			e1.printStackTrace();
		
		}
		
		// Code to store details in storetotalamount table in database
		
				try {
					Connection conn2 = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
					String query1 ="insert into storetotalamount (phoneNumber,totalAmount,refNo) values(?,?,?)";
					PreparedStatement pst1 =(PreparedStatement) conn2.prepareStatement(query1);
					
					System.out.println((String) txtFieldNumber.getText());
					System.out.println((String) textFieldTotalAmt.getText());
					System.out.println((String) textFieldRefNo.getText());
					
					
					pst1.setString(1, (String) txtFieldNumber.getText());
					pst1.setString(2, (String) textFieldTotalAmt.getText());
					pst1.setString(3, (String) textFieldRefNo.getText());
					
					pst1.executeUpdate();
					
					pst1.close();
					
				} catch(Exception e1){
				    e1.printStackTrace();
				 	};
				 	
				 	// Code to send SMS to the mobile number imported from TWILIO .jar file
				 	
				 	String ACCOUNT_SID = "ACf89bab8b4c96f879dc44eb16934c71fd";
					   String AUTH_TOKEN = "f21b3c3f4d6dc79084a0ee31f2975eb0";

					String sample = "+1"+ txtFieldNumber.getText();
					String sendsms = "You have shopped for USD."+ textFieldTotalAmt.getText()+ " .To View your ebill And Previous Purchase History Login To:www.MyALLBills.com Using Billing no:"+textFieldRefNo.getText();
					System.out.println(sample);
					    Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

					    Message message = Message.creator(new PhoneNumber(sample),
					        new PhoneNumber("+19897022496"), 
					        sendsms ).create();

					    System.out.println(message.getSid());
		
	}
});
btnSubmit.setForeground(SystemColor.textHighlight);
btnSubmit.setFont(new Font("Tahoma", Font.BOLD, 14));
btnSubmit.setBounds(223, 529, 124, 33);
frame.getContentPane().add(btnSubmit);
JSeparator separator_1 = new JSeparator();
separator_1.setBounds(10, 171, 833, 2);
frame.getContentPane().add(separator_1);
JSeparator separator_2 = new JSeparator();
separator_2.setBounds(10, 584, 833, 2);
frame.getContentPane().add(separator_2);
JButton btnUpdate = new JButton("Update");
btnUpdate.setForeground(SystemColor.textHighlight);
btnUpdate.setFont(new Font("Tahoma", Font.BOLD, 13));
btnUpdate.addActionListener(new ActionListener() {
	public void actionPerformed(ActionEvent e) {
		float price,quantity1;
		float subtotalofitem;
		
		// Code to store values from application to usercartdetails table in database 
		
		
		try {
			price = Float.parseFloat(textFieldPrice.getText());
			quantity1 = Float.parseFloat(textFieldQuantity.getText());
			
		//	double a = 	Math.round(b*100)/100;		
			subtotalofitem = price * quantity1;
			System.out.println(subtotalofitem);
			Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
		//    String query = "insert into usercartdetails (phoneNumber,selectedItem,itemUnitPrice,quantity) values(phoneNumber1,(String) comboBox.getSelectedItem(),(String) textFieldPrice.getText(),quantity)";
			String query ="insert into usercartdetails (phoneNumber,selectedItem,itemUnitPrice,quantity,subTotal,uniqueId) values(?,?,?,?,?,?)";
			PreparedStatement pst =(PreparedStatement) conn.prepareStatement(query);
			pst.setString(1, (String) txtFieldNumber.getText());
			pst.setString(2, (String) comboBox.getSelectedItem());
			pst.setString(3, (String) textFieldPrice.getText());
			pst.setString(4, (String) textFieldQuantity.getText());
			pst.setFloat(5, subtotalofitem);
			pst.setString(6, (String) textFieldRefNo.getText());
		    pst.executeUpdate();
			
			pst.close();
			} catch (Exception e1) {
				e1.printStackTrace();
			}
		
		// COde to populate usercartdtails Table data in jTable
		
		try {
			Connection conn1 = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/itempricetable","root","xavier");
			String query1 ="SELECT selectedItem,itemUnitPrice,quantity,subTotal FROM usercartdetails WHERE uniqueId = ? ";
			PreparedStatement pst =(PreparedStatement) conn1.prepareStatement(query1);
			pst.setString(1, (String) textFieldRefNo.getText());
			
			
			ResultSet rs1 = pst.executeQuery();
		//	rs1.next();
			table.setModel(DbUtils.resultSetToTableModel(rs1));	
		//	System.out.println(rs1.getString("itemUnitPrice"));
		//	System.out.println("WORKING ");
			
			pst.close();
		       } catch (Exception e1) {
			    e1.printStackTrace();
		       		}
		
		}
		
});
btnUpdate.setBounds(383, 130, 80, 24);
frame.getContentPane().add(btnUpdate);
textFieldRefNo = new JTextField();
textFieldRefNo.setForeground(SystemColor.textHighlight);
textFieldRefNo.setFont(new Font("Tahoma", Font.BOLD, 20));
textFieldRefNo.setBackground(Color.LIGHT_GRAY);
textFieldRefNo.setBounds(707, 118, 136, 42);
frame.getContentPane().add(textFieldRefNo);
textFieldRefNo.setColumns(10);
JLabel lblRefNo = new JLabel("Ref No");
lblRefNo.setFont(new Font("Segoe Print", Font.BOLD, 16));
lblRefNo.setBounds(632, 122, 65, 28);
frame.getContentPane().add(lblRefNo);

		
		fillComboBox();
		
	}
}
